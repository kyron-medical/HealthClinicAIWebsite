
import Link from "next/link";
import { Analytics } from "@vercel/analytics/react";
import RequestDemoButton from "../Common/RequestDemoButton";

const Hero = () => {
  return (
    <div className="hero-section text-center">
      <h1 className="text-4xl font-bold mb-4">Welcome to Health Clinic AI</h1>
      <p className="text-lg mb-6">
        Automate your administrative tasks and focus more on patient care.
      </p>
      <RequestDemoButton />

      <section className="my-8 text-center">
        <h2 className="text-3xl font-bold mb-4">Our Front-End Prototype</h2>
        <img src="/images/frontend-prototype.png" alt="Front-End Prototype" className="mx-auto w-1/2"/>
      </section>

      <section className="my-8 text-center">
        <h2 className="text-3xl font-bold mb-4">GUI Demo Video</h2>
        <video controls className="mx-auto w-1/2">
          <source src="/videos/gui-demo.mov" type="video/mp4"/>
          Your browser does not support the video tag.
        </video>
      </section>
    </div>
  );
};

export default Hero;
